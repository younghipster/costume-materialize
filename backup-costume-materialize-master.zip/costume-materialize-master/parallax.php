<?php echo "<br /><br /><br /><br /><br /><br /><br /><br /><br />"; ?>
<?php echo "<br /><br /><br /><br /><br /><br /><br /><br /><br />"; ?>

<main>
<!--  Start Parallax Section  -->
  <div class="parallax-container">
    <div class="parallax"><img src="img/1.jpg">
</div>
</div>
  <center>
  <div class="section white">
    <div class="row container">
      <h2 class="header">Hipster Company</h2>
      <p class="grey-text text-darken-3 lighten-3">
Website ini dibangun dengan parallax & slider with materialize framework Under License By MIT.</p>
    </div>
    <div class="row container"> 
      <h4 class="light">Basic Parallax code <i class="Medium material-icons">code</i></h4>
      <?php include('code/code1.php'); ?>

      <h4 class="light">Basic Slider code  <i class="Medium material-icons">code</i></h4>
      <?php include('code/code2.php'); ?>

    </div>
</div>
</center>
<!--  Start Parallax Section  -->
  <div class="parallax-container">
    <div class="parallax"><img src="img/5.jpg">
</div>
</div>

<!-- Start with-card -->
  <div class="section white">
      <center><h2 class="header">Hipster Service</h2>
<div class="row">
          <div class="col l4 s12">
          <div class="card">
            <div class="card-image">
              <img src="img/15.jpg">
              <span class="card-title">Hipster Style</span>
            </div>
            <div class="card-content">
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
            <div class="card-action">
              <a href="#">This is a link</a>
            </div>
          </div>
        </div>
<div class="row">
          <div class="col l4 s12">
          <div class="card">
            <div class="card-image">
              <img src="img/3.jpg">
              <span class="card-title">Hipster Photographs</span>
            </div>
            <div class="card-content">
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.</p>
            </div>
            <div class="card-action">
              <a href="#">This is a link</a>
            </div>
          </div>
        </div>
<div class="row">
          <div class="col l4 s12">
          <div class="card">
            <div class="card-image">
              <img src="img/1.jpg">
              <span class="card-title">Hipster Life</span>
            </div>
            <div class="card-content">
              <p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.<br /><br /></p>
            </div>
            <div class="card-action">
              <a href="#">This is a link</a>
            </div>
          </div>
        </div>
   </div><!-- section white -->

    <div class="row container"><!-- Start Basic code container -->
<h4 class="light">Basic Card Code <i class="Medium material-icons">code</i></h4>
      <?php include('code/code3.php'); ?>
</center>
</div><!-- End Basic code container -->
<!-- End with-card -->
</div>
  <div class="parallax-container">
    <div class="parallax"><img src="img/14.jpg"></div>
  </div> <!--  End Parallax Section  -->
</main>

