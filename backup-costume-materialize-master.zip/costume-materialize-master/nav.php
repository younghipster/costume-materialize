<!-- start Navbar -->
<div class="navbar-fixed">
    <nav>

<!-- Navbar slide Mobile device -->
<ul id="slide-out" class="side-nav">
    <li><div class="userView">
      <img class="background" src="img/5.jpg">
      <a href="#!puji122"><img class="circle" src="img/hipster7.jpg" /></a>
      <a href="#!Puji Ermanto"><span class="white-text name">puji122 <i class="Tiny material-icons">person_pin</i>Front-End : Puji Ermanto</span></a>
      <a href="#!pujiermanto@gmail.com"><span class="white-text email"><i class="material-icons">email</i>pujiermanto@gmail.com</span></a>
    </div></li>
    <li><a href="https://github.com/puji122/costume-materialize.git"><i class="material-icons">settings_cell</i>Website With Materialize</a></li>
    <li><a href="http://hipster.comli.com/"><i class="material-icons">question_answer</i>My Blog</a></li>
    <li><div class="divider"></div></li>
    <li><a class="subheader">Profile Front End</a></li>
    <li><a class="waves-effect" href="http://younghipster.netne.net"><i class="material-icons">android</i>PortFolio</a></li>
  </ul>
  <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>
<!-- Navbar slide Mobile device -->
      <div class="nav-wrapper brown">
        <div class="col s12">
          <a href="" class="brand-logo"><img src="img/logo1.png" widht="100px" height="50px" hspace="20" /></a>
          <ul class="right hide-on-med-and-down">
            <li><a href="sass.html">OurService</a></li>
            <li><a href="components.html">Fron-End Web</a></li>    
		<li><a href="components.html">Back-End Web</a></li>
          </ul>
        </div>
      </div>
    </nav><!-- End Navbar -->
  </div>
