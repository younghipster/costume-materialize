<pre><code class="language-markup col s12">
&lt;div class="row">
        &lt;div class="col s12 m6">
          &lt;div class="card blue-grey darken-1">
            &lt;div class="card-content white-text">
              &lt;span class="card-title">Card Title&lt;/span>
              &lt;p>I am a very simple card. I am good at containing small bits of information.
              I am convenient because I require little markup to use effectively.&lt;/p>
            &lt;/div>
            &lt;div class="card-action">
              &lt;a href="#">This is a link&lt;/a>
              &lt;a href="#">This is a link&lt;/a>
            &lt;/div>
          &lt;/div>
        &lt;/div>
      &lt;/div>
</code></pre>