<pre><code class="language-markup col s12">
&lt;div class="parallax-container">
    &lt;div class="parallax">&lt;img src="images/parallax1.jpg">&lt;/div>
  &lt;/div>
  &lt;div class="section white">
    &lt;div class="row container">
      &lt;h2 class="header">Parallax&lt;/h2>
      &lt;p class="grey-text text-darken-3 lighten-3">Parallax is an effect where the background content or image in this case, is moved at a different speed than the foreground content while scrolling.&lt;/p>
    &lt;/div>
  &lt;/div>
  &lt;div class="parallax-container">
    &lt;div class="parallax">&lt;img src="images/parallax2.jpg">&lt;/div>
  &lt;/div>
 </code></pre>