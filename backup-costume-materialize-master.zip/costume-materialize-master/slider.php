<div class="slider fullscreen">
  <ul class="slides">
    <li>
      <img src="img/2.jpg"> <!-- random image -->
      <div class="caption center-align">
        <h3>Hipster Company</h3>
        <h5 class="light grey-text text-lighten-3"> <span style = "color:#FAFAD2;">Hi! Welcome To Our Website.</span></h5>
      </div>
    </li>
    <li>
      <img src="img/6.jpg"> <!-- random image -->
      <div class="caption left-align">
        <h3>Photograph for Your Website</h3>
        <h5 class="light grey-text text-lighten-3"> <span style = "color:#FAFAD2;">Objek Yang akan Selalu Mengisi Ruang Dan Waktumu.</span></h5>
      </div>
    </li>
    <li>
      <img src="img/3.jpg"> <!-- random image -->
      <div class="caption right-align">
        <h3>Join With Us</h3>
        <h5 class="light grey-text text-lighten-3">Plan Your Project.</h5>
      </div>
    </li>
    <li>
      <img src="img/10.jpg"> <!-- random image -->
      <div class="caption center-align">
        <h3 style="color:#FFF8DC;">Catty the cat</h3>
        <h5 class="light grey-text text-lighten-3"><span style="color:#DC143C;">She&#39;s always making fun of his weird and long teeth.</span></h5>
      </div>
    </li>
    <li>
      <img src="img/9.jpg"> <!-- random image -->
      <div class="caption left-align">
        <h3 style="color:#F0F8FF;">slider on parallax Mywebsite template concept</h3>
        <h5 class="light grey-text text-lighten-3"><span style = "color:#FAFAD2;">clone template on</span><a href="https://github.com/puji122/slider-with-materialize/">&nbsp;My Github.</a></h5>
      </div>
    </li>
    <li>
      <img src="img/16.jpg"> <!-- random image -->
      <div class="caption right-align">
        <h3 style="color:#FFF8DC;">It&#39;s gleaming in my eyes</h3>
        <h5 class="light grey-text text-lighten-3"><span style="color:#DC143C;"><em>Lovely,</em> oh... </span> <span style = "color:#FAFAD2;">the light I can see.</span></h5>
      </div>
    </li>

  </ul>
</div>
