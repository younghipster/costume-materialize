$(document).ready(function(){
  $('.slider').slider({
    full_width: true,
    interval:5000,
    transition:800,
  });
});